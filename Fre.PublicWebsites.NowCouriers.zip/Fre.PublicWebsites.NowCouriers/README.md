# Now Couriers Marketing website

## UI Integration Test

    How to run the UI integration tests - local
    Option 1: (via click and run)
    $ npm install cypress --save-dev
    $ ./node_modules/.bin/cypress open
    Select the intended test and run
    Option 2: (via CLI)
    $ npm install cypress --save-dev
    $ ./node_modules/.bin/cypress run
    This runs all the tests from command line inteface


